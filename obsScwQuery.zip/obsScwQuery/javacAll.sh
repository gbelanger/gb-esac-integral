javac -cp .:ojdbc14.jar *.java
